Membrane SOA Router 
=====================

1. Starting the Router (Windows)
	Execute memrouter.bat
	
2. Starting the Router (Linux)
	Execute memrouter.sh
	
3. Optional command line arguments:
	-c 'configurationFileName'
		if not specified, Router looks for ROOT/conf/rules.xml
		
	-b 'springConfigurationFileName'
		if not specified, Router looks for ROOT/conf/monitor-beans.xml 